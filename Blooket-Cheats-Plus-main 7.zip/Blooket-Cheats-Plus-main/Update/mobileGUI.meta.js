// ==UserScript==
// @name         Blooket Cheats Plus
// @namespace    https://github.com/DannyDan0167/Blooket-Cheats
// @version      15.1
// @description  Blooket Cheats Plus
// @updateURL    https://raw.githubusercontent.com/DannyDan0167/Blooket-Cheats-Plus/main/Update/mobileGUI.meta.js
// @downloadURL  https://raw.githubusercontent.com/DannyDan0167/Blooket-Cheats-Plus/main/MobileGUI/mobileGui.user.js
// @author       DannyDan0167
// @match        https://dashboard.blooket.com/*
// @match        https://play.blooket.com/*
// @match        https://towerdefense2.blooket.com/*
// @match        https://monsterbrawl.blooket.com/*
// @match        https://towerdefense.blooket.com/*
// @match        https://cafe.blooket.com/*
// @match        https://factory.blooket.com/*
// @match        https://crazykingdom.blooket.com/*
// @match        https://towerofdoom.blooket.com/*
// @match        https://goldquest.blooket.com/*
// @match        https://cryptohack.blooket.com/*
// @match        https://fishingfrenzy.blooket.com/*
// @match        https://deceptivedinos.blooket.com/*
// @match        https://battleroyale.blooket.com/*
// @match        https://racing.blooket.com/*
// @match        https://blookrush.blooket.com/*
// @match        https://classic.blooket.com/*
// @match        https://pirate.blooket.com/*
// @icon         https://i.ibb.co/sWqBm0K/1024.png
// @grant        none
// @require     https://unpkg.com/idb-keyval@6.0.3/dist/umd.js
// ==/UserScript==
