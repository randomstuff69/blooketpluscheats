// ==UserScript==
// @name         Blooket Cheats Plus
// @namespace    https://github.com/DannyDan0167/Blooket-Cheats
// @version      15.4
// @description  Blooket Cheats Plus
// @updateURL    https://raw.githubusercontent.com/DannyDan0167/Blooket-Cheats-Plus/main/Update/Gui.meta.js
// @downloadURL  https://raw.githubusercontent.com/DannyDan0167/Blooket-Cheats-Plus/main/GUI/Gui.user.js
// @author       DannyDan0167
// @match        *://*.blooket.com/*
// @icon         https://i.ibb.co/sWqBm0K/1024.png
// @grant        none
// @require     https://unpkg.com/idb-keyval@6.0.3/dist/umd.js
// ==/UserScript==
